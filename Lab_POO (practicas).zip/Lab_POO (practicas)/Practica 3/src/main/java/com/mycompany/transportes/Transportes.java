/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.transportes;

public class Transportes {
    
    public static void main(String args[]){
        
        Automobil jeep = new Automobil(10, 10920);
        Automobil honda = new Automobil(20, 10928);
        
        System.out.println(jeep.EncenderMotor() + "\n" + jeep.Manejo()+ "\n" 
                            + jeep.sistemaElectrico()+ "\n" + jeep.sistemaFrenos() + "\n"
                            + jeep.Apagar());
        
        System.out.println(honda.EncenderMotor() + "\n" + honda.Manejo()+ "\n" 
                            + honda.sistemaElectrico()+ "\n" + honda.sistemaFrenos() + "\n"
                            + honda.Apagar());
        
        
    }
    
}
