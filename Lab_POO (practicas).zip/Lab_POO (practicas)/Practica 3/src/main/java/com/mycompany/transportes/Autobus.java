/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.transportes;


public class Autobus extends ATransportes implements ITransportes {
    
    private int combustible;
    private int matricula;
    
    public Autobus(){
 
    }
    
    public Autobus(int combustible, int matricula){
        this.combustible = combustible;
        this.matricula = matricula;
    }
    
    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
    
    void setCombustible(int a){
        this.combustible = a;
    }
    
    int getCombustible(){
        return this.combustible;
    }
    
    @Override
    public String Apagar() {
        return "Apagar autobus " + this.matricula;
    }

    @Override
    public String Manejo() {
        return "Manejar autobus " + this.matricula;
    }

    @Override
    public String sistemaElectrico() {
        return "Sistema Electrico autobus " + this.matricula;
    }

    @Override
    public String sistemaFrenos() {
        return "Sistema frenos autobus " + this.matricula;
    }
    
    public String EncenderMotor() {
        if (this.combustible>=1)
        {
            return "Enciende el motor";
        }
        else{
            return "Falta gasolina";
        }
        
    }
        
}
