/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.transportes;


public class Automobil extends ATransportes implements ITransportes {
    
    private int combustible;
    private int matricula;
    
    public Automobil(){
    
    }
    
    public Automobil(int combustible, int matricula){
        this.combustible = combustible;
        this.matricula = matricula;
    }
    
    public int getCombustible() {
        return combustible;
    }

    public void setCombustible(int combustible) {
        this.combustible = combustible;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
    
    
    
    @Override
    public String Apagar() {
        return "Apagar automobil " + this.matricula;
    }

    @Override
    public String Manejo() {
        return "Manejar automobil " + this.matricula;
    }

    @Override
    public String sistemaElectrico() {
        return "Sistema electrico automobil " + this.matricula;
    }

    @Override
    public String sistemaFrenos() {
        return "Sistema frenos automobil " + this.matricula;
    }
    
    public String EncenderMotor() {
        if (this.combustible>=1)
        {
            return "Enciende el motor";
        }
        else{
            return "Falta gasolina";
        }
        
    }
    
}
