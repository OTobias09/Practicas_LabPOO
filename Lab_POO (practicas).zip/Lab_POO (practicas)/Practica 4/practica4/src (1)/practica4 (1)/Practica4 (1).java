/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;

import java.sql.*;


/**
 *
 * @author FCFM
 */
public class Practica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        try{
            String url = "jdbc:mysql://localhost:3306/p5";
            Connection conn = DriverManager.getConnection(url, "test", "test123");
            Statement st = conn.createStatement();
            st.executeUpdate("INSERT INTO p5t");
            conn.close();
        }catch(Exception e){
            System.err.println(e);
        }*/
        
        aplicacion main = new aplicacion();
        main.setVisible(true);
        
        
    }
    
}
