/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practica1;

public class Calculadora implements ICalculadora{
    
    private int a;
    private int b;
    
    public Calculadora(){
        this.a = 0;
        this.b = 0;
        
    }
    
    public Calculadora(int a, int b) {
        this.a = a;
        this.b = b;
    }
    
    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
    
    public int suma(){  
        int x = this.a + this.b;
        return x;
    }
    
    public int resta(){
        int x = this.a - this.b;
        return x;
    }
    
    public int multiplicacion(){
        int x = this.a * this.b;
        return x;
    }
    
    public int division(){
        int x = this.a / this.b;
        return x;
    }
    
}
