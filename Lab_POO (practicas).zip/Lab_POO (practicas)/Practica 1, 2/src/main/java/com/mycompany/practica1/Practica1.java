/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.practica1;

public class Practica1 {
    
    public static void main(String args[]){
    
        Calculadora calc =  new Calculadora(10, 5);
        Calculadora calc1 = new Calculadora();
        
        System.out.println("Suma: " + calc.suma() + "\n");
        System.out.println("Resta: " + calc.resta() + "\n");
        System.out.println("Multiplicacion: " + calc.multiplicacion() + "\n");
        System.out.println("Division: " + calc.division() + "\n");
        
        calc1.setA(40);
        calc1.setB(10);
        
        System.out.println("Suma: " + calc1.suma() + "\n");
        System.out.println("Resta: " + calc1.resta() + "\n");
        System.out.println("Multiplicacion: " + calc1.multiplicacion() + "\n");
        System.out.println("Division: " + calc1.division() + "\n");
    }
    
}
